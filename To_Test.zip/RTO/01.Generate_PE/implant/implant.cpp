/*

 Red Team Operator course code template - EXE
 author: reenz0h (twitter: @sektor7net)

*/
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
	printf("RT Operator, here I come!\n");
	getchar();
	return 0;
}
